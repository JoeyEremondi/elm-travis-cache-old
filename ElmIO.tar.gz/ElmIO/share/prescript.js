var jsdom = require("jsdom");
var callback = function(errors, window) {
    var document = window.document;
// Elm goes here:
